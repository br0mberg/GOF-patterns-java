package creational.abstractfactory.interfaces;

public interface MessageConsumer {
    void subscribe(String topic);
}
