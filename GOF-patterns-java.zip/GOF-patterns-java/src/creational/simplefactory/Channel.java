package creational.simplefactory;

enum Channel { EMAIL, SMS }
